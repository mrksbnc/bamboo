import{_ as i,s as a,I as t,B as o}from"./index-DDnE1tkY.js";import"./iframe-DuGl65Uy.js";import"../sb-preview/runtime.js";import"./vue.esm-bundler-De164cfR.js";const u={title:"Icon/bo-icon",component:i,tags:["autodocs"],argTypes:{icon:{description:"The name of the icon",table:{category:"props",subcategory:"required",type:{summary:"Icon",detail:a(t,"Icon")}},control:{type:"select"},options:Object.values(t)},size:{description:"The size of the icon",table:{category:"props",subcategory:"optional",type:{summary:"BoSize",detail:a(o,"BoSize")},defaultValue:{summary:o.default}},control:{type:"select"},options:Object.values(o)},color:{description:"The color of the icon in `hex` format",table:{category:"props",subcategory:"optional",type:{summary:"string"},defaultValue:{summary:null}},control:{type:"color"}}}},e={args:{icon:t.airplay,size:o.default}};var r,s,c;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:`{
  args: {
    icon: Icon.airplay,
    size: BoSize.default
  }
}`,...(c=(s=e.parameters)==null?void 0:s.docs)==null?void 0:c.source}}};const y=["Example"];export{e as Example,y as __namedExportsOrder,u as default};
//# sourceMappingURL=bo_icon.stories-BtzzhvYH.js.map
