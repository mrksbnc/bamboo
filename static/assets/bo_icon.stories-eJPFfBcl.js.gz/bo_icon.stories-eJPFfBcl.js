import{_ as i,S as a,I as t,B as e}from"./index-CmNQD-HU.js";import"./iframe-DRPT1DR7.js";import"../sb-preview/runtime.js";import"./vue.esm-bundler-DlZOrE6n.js";const u={title:"Icon/bo-icon",component:i,tags:["autodocs"],argTypes:{icon:{description:"The name of the icon",table:{category:"props",subcategory:"required",type:{summary:"Icon",detail:a.stringEnumFormatter(t,"Icon")}},control:{type:"select"},options:Object.values(t)},size:{description:"The size of the icon",table:{category:"props",subcategory:"optional",type:{summary:"BoSize",detail:a.stringEnumFormatter(e,"BoSize")},defaultValue:{summary:e.default}},control:{type:"select"},options:Object.values(e)},color:{description:"The color of the icon in `hex` format",table:{category:"props",subcategory:"optional",type:{summary:"string"},defaultValue:{summary:null}},control:{type:"color"}}}},o={args:{icon:t.airplay,size:e.default}};var r,s,c;o.parameters={...o.parameters,docs:{...(r=o.parameters)==null?void 0:r.docs,source:{originalSource:`{
  args: {
    icon: Icon.airplay,
    size: BoSize.default
  }
}`,...(c=(s=o.parameters)==null?void 0:s.docs)==null?void 0:c.source}}};const y=["Example"];export{o as Example,y as __namedExportsOrder,u as default};
//# sourceMappingURL=bo_icon.stories-eJPFfBcl.js.map
